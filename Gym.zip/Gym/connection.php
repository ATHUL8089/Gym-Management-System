<?php
$con = mysqli_connect("localhost", "root", "");
if (!$con) {
    die(" Connection Error ");
}
